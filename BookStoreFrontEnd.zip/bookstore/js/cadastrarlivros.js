$(document).ready(function(){
$("#cadastrar" ).on( "submit", function( event ) {
        event.preventDefault();
        $('#cadastro').addClass('disabled');
        let data=$(this).serializeObject();
        console.log(data);
        $.ajax({
            type:'POST',
            url:'http://localhost:3000/books',
            contentType:'application/json',
            data: JSON.stringify(data),
            dataType:'json',
            success: function(response){
              console.log(response[0]);
                if(Object.keys(response).length>1){
                  window.location.replace("index.html");
                    //var mensagem = "<strong>erro ao cadastrar usuario!</strong>";
                    //mostraDialogo(mensagem, "danger", 2500);
                }
                else{
                    //$('#cadastrar').modal('toggle');
                //$('#success').modal('show');
                    //var mensagem = "<strong>Usuário cadastrado</strong>";
                    //mostraDialogo(mensagem, "success", 2500);

                }
            }
        });
      });

});

