$.fn.serializeObject = function()
  {
     var o = {};
     var a = this.serializeArray();
     $.each(a, function() {
         if (o[this.name]) {
             if (!o[this.name].push) {
                 o[this.name] = [o[this.name]];
             }
             o[this.name].push(this.value || '');
         } else {
             o[this.name] = this.value || '';
         }
     });
     return o;
  };
function calculaDias(diaInicio,diaFim){
   diaInicio=moment(diaInicio).format('YYYY/MM/DD');
   diaFim=moment(diaFim).utc().format('YYYY/MM/DD');
  let dt1= new Date(Date.parse(diaInicio));
  let dt2= new Date(Date.parse(diaFim)+1);
  let dias= (dt2-dt1)/86400000;
  return Math.trunc(dias);

}
function SomenteNumero(e){
    let tecla=(window.event)?event.keyCode:e.which;   
    if((tecla>47 && tecla<58)) return true;
    else{
        if (tecla==8 || tecla==0) return true;
    else  return false;
    }
}
