function editarAluguel(){
  $('#btn-editar').click( function(){
      //let slider = $("#cadastra_evento");
      $("#inform").slideUp(400);
      $("#btn-editar").slideUp(400, function(){
          $("#editar").show().slideDown(400);
          $("#btn-cancelar").show().slideDown(400);
          $("#editar").show().slideDown();

      });
  });
  $('#btn-cancelar').click( function (){
      $("#btn-cancelar").hide();
      $("#editar").slideUp(400,function(){
          $("#inform").slideDown(400);
          $("#btn-editar").slideDown(400);
      });
  });
}
$("#extendData" ).click( function( event ) {
        event.preventDefault();
        $('#extendData').addClass('disabled');
        let id=$('#keepId').text();
        let data=$('#dataEntrega').val();
        //let data=$(this).serializeObject();
        data={start:data}
        console.log(data);
  $.ajax({
      type:'POST',
      url:`http://localhost:3000/rent/extend/${id}`,
      dataType:'json',
      data: data,
      success: function(response){
        window.location.replace('controlealugueis.html');
      }
    });
});
function setBookID(events){
  console.log(events);
  let bookId=events.extendedProps.book;
  $('#keepBookId').text(bookId);
}

$(document).ready(function(){
var calendarEl = document.getElementById('calendar');
    var calendar = new FullCalendar.Calendar(calendarEl, {
        timeZone:'America/Recife',
        locale: 'pt-br',
        buttonText: {
            prev: "Anterior",
            next: "Póximo",
            today: "Hoje",
            month: "Mês",
            week: "Semana",
            day: "Dia",
            hour: "Hora"
        },
        selectable: false,
        selectHelper: true,
        select: function(info) {
            $('#cadastrar #startmodal').val(moment(info.startStr).format('DD/MM/YYYY'));
            $('#cadastrar #endmodal').val(moment(info.endStr).format('DD/MM/YYYY'));
            $('#cadastrar').modal('show');
            return false
        },
        plugins: ['interaction', 'dayGrid', 'timeGrid'],
        header: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        navLinks: true, // can click day/week names to navigate views
        editable: true,
        eventLimit: true, // allow "more" link when too many events
        //events:,
        eventSources:[{
          method:'GET',
          url:'http://localhost:3000/rent'
        }],
        eventClick: function (info) {
            let eventObj = info.event;
            console.log(info.event);
            let id=eventObj.extendedProps._id;
            let title=eventObj.title;
            setBookID(eventObj);
            $('#keepId').text(id);
            $.ajax({
                type:'GET',
                url:`http://localhost:3000/rent/${id}`,
                dataType:'json',
                success: function(response){
                      let name=response.user.name;
                      let email=response.user.email;
                      let inicio=response.date;
                      let fim=response.start;
                      let price=response.price;
                      let quantDias=calculaDias(inicio,fim);
                      let total = quantDias*price;
                      //modal de visualizar dados do aluguel
                      $('#visualizar #title').text(title);
                      $('#visualizar #end').text(moment(fim).utc().format('DD/MM/YYYY'));
                      $('#visualizar #usuario').text(name);
                      $('#visualizar #email').text(email);
                      $('#visualizar #total').text(total);


                      //modal para extender o Aluguel
                      $('#editar #texto').val(title);
                      $('#visualizar #editar').hide();
                      $('#visualizar #btn-cancelar').hide();
                      $('#visualizar #btn-finalizar').hide();
                      $('#visualizar').show(400, function(){
                          $("#inform").slideDown(400);
                          $("#btn-editar").slideDown(400);
                      });
                      $('#btn-editar').show(400);
                      $('#visualizar').modal('show');
                      return false;
                      }
                  });editarAluguel();

              },
          });

            //$('#visualizar #id').text(eventObj._id);
            //$('#visualizar #title').text(eventObj.name);
            //$('#visualizar #local').text(eventObj.extendedProps.description);
            //$('#editar #texto').val(eventObj.name);
            //$('#visualizar #start').text(eventObj.start.toLocaleString());
            //$('#editar #startmodal').val(eventObj.start.toLocaleString());
            //$('#visualizar #end').text(eventObj.date.toLocaleString());
            //$('#editar #endmodal').val(eventObj.date.toLocaleString());

    calendar.render();
    calendar.setOption('locale', 'pt-br');

    $("#btn-finalizar" ).click( function( event ) {
            event.preventDefault();
            $('#extendData').addClass('disabled');
            let id=$('#keepId').text();
            let bookId=$('#keepBookId').text();
            //let data=$(this).serializeObject();
      $.ajax({
          type:'POST',
          url:`http://localhost:3000/rent/del/${id}/${bookId}`,
          success: function(response){
            window.location.replace('controlealugueis.html');
          }
        });
        window.location.replace('controlealugueis.html');
    });
});
function editarAluguel(){
  $('#btn-editar').click( function(){
      //let slider = $("#cadastra_evento");
      $("#inform").slideUp(400);
      $("#btn-editar").slideUp(400, function(){
          $("#editar").show().slideDown(400);
          $("#btn-cancelar").show().slideDown(400);
          $("#btn-finalizar").show().slideDown(400);
          $("#editar").show().slideDown();

      });
  });
  $('#btn-cancelar').click( function (){
      $("#btn-cancelar").hide();
      $("#btn-finalizar").hide();
      $("#editar").slideUp(400,function(){
          $("#inform").slideDown(400);
          $("#btn-editar").slideDown(400);
      });
  });
}
