function modalAlugar(_id){
//$('.cadastrar').on('click', function () {
    let id = _id;
    console.log(id);
    let titulo = $('#titulo_'+id).data("titulo");
    let price = $('#price_'+id).data("price");
    console.log(titulo);
    $('#cadastrar #title').text(titulo);
    $('#cadastrar #price').text(price);
    $('#cadastrar #keepId').text(id);
    $('#cadastrar').modal('show');
//});
}
$("#alugar").on( "submit", function( event ) {
  event.preventDefault();
  let name=$('#title').text();
  let data=$('#dataEntrega').val();
  let price=$('#price').text();
  let id=$('#keepId').text();
  let usuario=$('#dadosUsuario').val();

  data={title:name,start:data,price:price,user:usuario,book:id};
  console.log(id);
  $.ajax({
      type:'POST',
      url:`http://localhost:3000/rent/${id}`,
      contentType:'application/json',
      data: JSON.stringify(data),
      dataType:'json',
      success: function(response){
        window.location.replace('index.html');
      }
    });
});

function DataHora(evento, objeto) {
            var keypress = (window.event) ? event.keyCode : evento.which;
            campo = eval(objeto);
            if (campo.value == '00/00/0000') {
                campo.value = ""
            }

            caracteres = '0123456789';
            separacao1 = '/';
            conjunto1 = 2;
            conjunto2 = 5;
            conjunto3 = 10;
            if ((caracteres.search(String.fromCharCode(keypress)) != -1) && campo.value.length < (10)) {
                if (campo.value.length == conjunto1)
                    campo.value = campo.value + separacao1;
                else if (campo.value.length == conjunto2)
                    campo.value = campo.value + separacao1;
                else if (campo.value.length == conjunto3)
                    campo.value = campo.value + separacao2;
            } else {
                event.returnValue = false;
            }
        }
$(document).ready(function(){
  $.ajax({
      type:'GET',
      url:'http://localhost:3000/books',
      dataType:'json',
      success: function(response){
          if(Object.keys(response).length>0){
            $.each(response, function(i,obj){
              let {name}= obj
              let {category} = obj
              let {price} = obj
              let {quant} = obj
              let {_id} = obj
              let {url} = obj

              books='<div class="col-lg-4 col-md-6 mb-4" data-id="'+_id+'" id="'+_id+'">'
                books+='<div class="card h-100">'
                if(url===undefined){
                  books+='<img src="http://placehold.it/700x400" alt="" height="300">'
                }
                else{
                  books+='<img src="'+url+'"height="300" />'
                  }
                  books+='<div class="card-body">'
                    books+='<h4 class="card-title">'
                    books+='<h2 data-titulo="'+name+'" id="titulo_'+_id+'">'+name+'<h2>'
                    books+='</h4>'
                    books+='<h5 data-price="'+price+'" id="price_'+_id+'">R$ '+price+' por dia</h5>'
                    books+='<p class="card-text">'+category+'</p>'
                    books+='<p class="card-text">Quantidade disponível: '+quant+'</p>'
                  books+='</div>'
                  books+='<div class="card-footer" style="text-align: center">'
                  if(quant===0){
                    books+='<button class="btn btn-primary disabled" id="indisponível" >Indisponível</button>'
                  }else{
                    books+='<button class="btn btn-primary cadastrar" onClick="modalAlugar(\''+_id+'\')"> Alugar/Reservar</button>'
                    }
                  books+='</div>'
              books+='</div>'
              books+='</div>'
              $('#bookstand').append(books);

            });
          }
      }
  });
$.ajax({
    type:'GET',
    url:'http://localhost:3000/users',
    dataType:'json',
    success: function(response){
            let userData= document.getElementById('dadosUsuario');
            if(Object.keys(response).length>0){
              $.each(response, function(i,obj){
                let nome=obj.name;
                let id=obj._id;
                let optionNova = document.createElement("option");
                    optionNova.text=(nome);
                    optionNova.value=(id);
                    userData.appendChild(optionNova);
              })
            }
          }

      });
  });

  function buscaporCategoria(category){
    let item = document.getElementById("bookstand");
    item.parentNode.removeChild(item);
    let bookDiv = document.getElementsByClassName("col-lg-9");
    let optionNova = document.createElement("div");
    optionNova.setAttribute('class','row');
    optionNova.id="bookstand";
    bookDiv[0].appendChild(optionNova);
    $.ajax({
        type:'GET',
        url:`http://localhost:3000/books/find/${category}`,
        dataType:'json',
        success: function(response){
            if(Object.keys(response).length>0){
              $.each(response, function(i,obj){
                let {name}= obj
                let {category} = obj
                let {price} = obj
                let {quant} = obj
                let {_id} = obj
                let {url} = obj

                books='<div class="col-lg-4 col-md-6 mb-4" data-id="'+_id+'" id="'+_id+'">'
                  books+='<div class="card h-100">'
                  if(url===undefined){
                    books+='<img src="http://placehold.it/700x400" alt="" height="300">'
                  }
                  else{
                    books+='<img src="'+url+'"height="300" />'
                    }
                    books+='<div class="card-body">'
                      books+='<h4 class="card-title">'
                      books+='<h2 data-titulo="'+name+'" id="titulo_'+_id+'">'+name+'<h2>'
                      books+='</h4>'
                      books+='<h5 data-price="'+price+'" id="price_'+_id+'">R$ '+price+' por dia</h5>'
                      books+='<p class="card-text">'+category+'</p>'
                      books+='<p class="card-text">Quantidade disponível: '+quant+'</p>'
                    books+='</div>'
                    books+='<div class="card-footer" style="text-align: center">'
                    if(quant===0){
                      books+='<button class="btn btn-primary disabled" id="indisponível" >Indisponível</button>'
                    }else{
                      books+='<button class="btn btn-primary cadastrar" onClick="modalAlugar(\''+_id+'\')"> Alugar/Reservar</button>'
                      }
                    books+='</div>'
                books+='</div>'
                books+='</div>'
                $('#bookstand').append(books);

              });
            }
        }
    });
  }
