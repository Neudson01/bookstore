$(document).ready(function(){
  $.ajax({
      type:'GET',
      url:'http://localhost:3000/books',
      dataType:'json',
      success: function(response){
          if(Object.keys(response).length>0){
            $.each(response, function(i,obj){
              let {name}= obj
              let {category} = obj
              let {price} = obj
              let {quant} = obj
              let {_id} = obj
              let {url} = obj
                  let books='<tr>'
                    books+=`<td>${name}</td>`
                    books+='<td><button id="btn-editar" data-id="editar_'+_id+'" class="btn btn-success" onClick="modalEditar(\''+_id+'\')">Editar</button><button id="btn-excluir" data-id="excluir_'+_id+'" class="btn btn-warning" onClick="excluirLivro(\''+_id+'\')"">Excluir Livro</button></td>'
                  books+='</tr>'
                  $('#booksTable').append(books);
            });
          }
      }
    });
});
function modalEditar(_id){
//$('.cadastrar').on('click', function () {
let id = _id;
$.ajax({
    type:'GET',
    url:`http://localhost:3000/books/${id}`,
    dataType:'json',
    success: function(response){
            let {name}= response
            let {category} = response
            let {price} = response
            let {quant} = response
            let {_id} = response
            let {url} = response
            let {description}=response
            //let titulo = $('#titulo_'+id).data("titulo");
            //let price = $('#price_'+id).data("price");
            $('#editar #name').val(name);
            $('#editar #price').val(price);
            $('#editar #quant').val(quant);
            //$('#editar #category').text(category);
            $('#editar #description').text(description);
            $('#editar #url').val(url);
            $('#editar #keepId').text(id);
            $('#visualizar').modal('show');
            $('#btn-cancelar').click( function (){
              $('#visualizar').modal('toggle')
        });
      }
  });
$("#salvar" ).click( function(event) {
          event.preventDefault();
          $('#salvar').addClass('disabled');
          let name=$('#name').val();
          let quant=$('#editar #quant').val();
          let price=$('#price').val();
          let description=$('#editar #description').text();
          let url = $('#editar #url').val();
          obj={name:name,quant:quant,price:price,description:description,url:url};
          console.log(obj);
          $.ajax({
              type:'POST',
              url:`http://localhost:3000/books/altera/${id}`,
              contentType:'application/json',
              data: JSON.stringify(obj),
              dataType:'json',
              success: function(response){
                console.log(response[0]);
                  if(Object.keys(response).length>1){
                    window.location.replace("editarlivros.html");
                      //var mensagem = "<strong>erro ao cadastrar usuario!</strong>";
                      //mostraDialogo(mensagem, "danger", 2500);
                  }
                  else{
                      //$('#cadastrar').modal('toggle');
                  //$('#success').modal('show');
                      //var mensagem = "<strong>Usuário cadastrado</strong>";
                      //mostraDialogo(mensagem, "success", 2500);

                  }
              }
          });
        });

}



function excluirLivro(_id){
 let id=_id;
    $.ajax({
        type:'POST',
        url:`http://localhost:3000/books/del/${id}`,
        success: function(response){
        }
      });
      window.location.replace('editarlivros.html');
}
